package com.example.recyclerviewpractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerViewCars : RecyclerView
    private lateinit var data : ArrayList<Car>
    private lateinit var carAdapter : CarAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerViewCars = findViewById<RecyclerView>(R.id.recyclerViewList)
        recyclerViewCars.layoutManager = LinearLayoutManager(this)

        data = ArrayList<Car>()
        data.add(Car("Encore", "Buico", "2019"))
        data.add(Car("Liberty", "Jeep", "2006"))
        data.add(Car("Mr. M", "Mustang", "1969"))

        carAdapter = CarAdapter(data)
        recyclerViewCars.adapter = carAdapter
    }
}