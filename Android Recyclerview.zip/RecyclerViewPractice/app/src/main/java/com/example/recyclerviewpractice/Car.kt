package com.example.recyclerviewpractice

class Car (var name:String, var brand:String, var year:String) {
}