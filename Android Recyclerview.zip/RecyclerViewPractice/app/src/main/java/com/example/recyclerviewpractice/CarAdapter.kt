package com.example.recyclerviewpractice

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CarAdapter (private var carList: List<Car>) :
    RecyclerView.Adapter<CarAdapter.CarViewHolder>()
{
    inner class CarViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewName: TextView = itemView.findViewById(R.id.textViewName)
        val textViewBrand: TextView = itemView.findViewById(R.id.textViewBrand)
        val textViewYear: TextView = itemView.findViewById(R.id.textViewYear)
    } // end MyViewHolder

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.current_recyclerview_list, parent, false)
        return CarViewHolder(view)
    } // other code goes here...

    override fun onBindViewHolder(holder: CarViewHolder, position: Int) {
        val car = carList[position]
        holder.textViewName.setText(car.name)
        holder.textViewBrand.setText(car.brand)
        holder.textViewYear.setText(car.year)
    }

    override fun getItemCount(): Int {
        return carList.size
    }

    fun setData(list: List<Car>)
    {
        carList = list
        notifyDataSetChanged()
    }
    }